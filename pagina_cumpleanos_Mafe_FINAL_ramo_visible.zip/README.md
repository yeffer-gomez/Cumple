# Página de cumpleaños para Mafe ❤️

Página romántica y elegante para GitHub Pages.

## Archivos
- index.html
- style.css
- script.js

## Publicar
Sube los tres archivos a la raíz del repositorio, en la rama `main`, y activa GitHub Pages desde Settings → Pages → Deploy from a branch → `main` → `/ (root)`.


La página incluye `mafe-ramo.png`, una ilustración romántica con animación CSS que simula el gesto de acercar el ramo.
